#import <UIKit/UIKit.h>

FOUNDATION_EXPORT double ToasterVersionNumber;
FOUNDATION_EXPORT const unsigned char ToasterVersionString[];
